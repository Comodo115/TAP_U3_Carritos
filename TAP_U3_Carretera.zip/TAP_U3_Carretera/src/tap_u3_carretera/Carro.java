package tap_u3_carretera;

public class Carro {
    
    public int[] carroX;
    public int[] carroY;

    public Carro(int[] carroX, int[] carroY) {
        this.carroX = carroX;
        this.carroY = carroY;
    }
    
}
