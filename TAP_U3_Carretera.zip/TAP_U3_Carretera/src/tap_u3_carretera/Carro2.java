package tap_u3_carretera;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Carro2 extends Thread{
    
    int count = Ventana.lienzo.carro2.carroX[1];
    
    @Override
    public void run() {
        
        while(true){
            if((SemaforoInferior.estadoSemaforoInferior == true) || (SemaforoInferior.estadoSemaforoInferior == false && count > 730) || (SemaforoInferior.estadoSemaforoInferior == false && count < 730)){
                count -= 5;
                for(int i = 0; i < Ventana.lienzo.carro2.carroX.length; i++){
                    Ventana.lienzo.carro2.carroX[i] -= 5;              
                    if(Ventana.lienzo.carro2.carroX[i] == -100){
                        Ventana.lienzo.carro2.carroX[i] += 1200;
                        Ventana.lienzo.repaint();
                    }else{
                        Ventana.lienzo.repaint();
                    }

                    if(count == -100){
                        count += 1200;
                    }
                }

                try {
                    sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carro1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else if(SemaforoInferior.estadoSemaforoInferior == false){
                try {
                    sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carro2.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
}
