package tap_u3_carretera;

import java.util.logging.Level;
import java.util.logging.Logger;

class Carro4 extends Thread{
    
    int count = Ventana.lienzo.carro4.carroY[1];
    
    @Override
    public void run() {
        while(true){
            if((SemaforoSuperior.estadoSemaforoSuperior == true) || (SemaforoSuperior.estadoSemaforoSuperior == false && count > 150) || (SemaforoSuperior.estadoSemaforoSuperior == false && count < 150)){
                count += 5;
                for(int i = 0; i < Ventana.lienzo.carro4.carroY.length; i++){
                    Ventana.lienzo.carro4.carroY[i] += 5;              
                    if(Ventana.lienzo.carro4.carroY[i] == 1080){
                        Ventana.lienzo.carro4.carroY[i] -= 1180;
                        Ventana.lienzo.repaint();
                    }else{
                        Ventana.lienzo.repaint();
                    }
                    
                    if(count == 1080){
                        count -= 1180;
                    }
                }

                try {
                    sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carro1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else if((SemaforoSuperior.estadoSemaforoSuperior == false)){
                try {
                    sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carro3.class.getName()).log(Level.SEVERE, null, ex);
                }
            }  
        }
    }
}
