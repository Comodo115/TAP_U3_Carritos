package tap_u3_carretera;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Carro3 extends Thread{
    
    int count = Ventana.lienzo.carro3.carroY[1];
    
    @Override
    public void run() {
        
        while(true){
            if((SemaforoSuperior.estadoSemaforoSuperior == true) || (SemaforoSuperior.estadoSemaforoSuperior == false && count > 570) || (SemaforoSuperior.estadoSemaforoSuperior == false && count < 570)){
                count -= 5;
                for(int i = 0; i < Ventana.lienzo.carro3.carroY.length; i++){
                    Ventana.lienzo.carro3.carroY[i] -= 5;              
                    if(Ventana.lienzo.carro3.carroY[i] == -100){
                        Ventana.lienzo.carro3.carroY[i] += 950;
                        Ventana.lienzo.repaint();
                    }else{
                        Ventana.lienzo.repaint();
                    }
                    
                    if(count == -100){
                        count += 950;
                    }
                }

                try {
                    sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carro1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else if((SemaforoSuperior.estadoSemaforoSuperior == false)){
                try {
                    sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carro3.class.getName()).log(Level.SEVERE, null, ex);
                }
            }    
        }
    }
    
}
