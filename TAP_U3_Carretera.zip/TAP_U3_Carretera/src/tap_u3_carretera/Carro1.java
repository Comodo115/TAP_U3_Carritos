package tap_u3_carretera;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Carro1 extends Thread{
    
    int count = Ventana.lienzo.carro1.carroX[1];
    
    @Override
    public void run() {
        
        while(true){
            if((SemaforoInferior.estadoSemaforoInferior == true) || (SemaforoInferior.estadoSemaforoInferior == false && count > 300) || (SemaforoInferior.estadoSemaforoInferior == false && count < 300)){
                count += 5;
                for(int i = 0; i < Ventana.lienzo.carro1.carroX.length; i++){
                    Ventana.lienzo.carro1.carroX[i] += 5;              
                    if(Ventana.lienzo.carro1.carroX[i] == 1100){
                        Ventana.lienzo.carro1.carroX[i] -= 1200;
                        Ventana.lienzo.repaint();
                    }else{
                        Ventana.lienzo.repaint();
                    }
                    
                    if(count == 1100){
                        count -= 1200;
                    }
                }

                try {
                    sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carro1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else if(SemaforoInferior.estadoSemaforoInferior == false){
                try {
                    sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carro1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
}
