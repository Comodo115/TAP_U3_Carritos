package tap_u3_carretera;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SemaforoInferior extends Thread{
    
    private final Color colorV = new Color(0,100,0);
    private final Color colorR = new Color(139,0,0);
    private final Color colorA = new Color(229,190,0);
    
    private final Color colorVL = new Color(0,255,0);
    private final Color colorRL = new Color(255,0,0);
    private final Color colorAL = new Color(255,255,0);
    
    public static boolean estadoSemaforoInferior = true; //true = avanzar, false = detenerce.
    
    @Override
    public void run() {
        while(true){
            try {
                if(SemaforoSuperior.estadoSemaforoSuperior){
                    Ventana.lienzo.setRojo2(colorRL);
                    Ventana.lienzo.setAmarillo2(colorA);
                    Ventana.lienzo.setVerde2(colorV);
                    sleep(1000);
                    Ventana.lienzo.setRojo2(colorR);
                    Ventana.lienzo.setAmarillo2(colorAL);
                    Ventana.lienzo.setVerde2(colorV);
                    sleep(1000);
                    Ventana.lienzo.setRojo2(colorR);
                    Ventana.lienzo.setAmarillo2(colorA);
                    Ventana.lienzo.setVerde2(colorVL);
                }else{
                    Ventana.lienzo.setRojo2(colorR);
                    Ventana.lienzo.setAmarillo2(colorA);
                    Ventana.lienzo.setVerde2(colorVL);
                    sleep(1000);
                    Ventana.lienzo.setRojo2(colorR);
                    Ventana.lienzo.setAmarillo2(colorAL);
                    Ventana.lienzo.setVerde2(colorV);
                    sleep(1000);
                    Ventana.lienzo.setRojo2(colorRL);
                    Ventana.lienzo.setAmarillo2(colorA);
                    Ventana.lienzo.setVerde2(colorV);
                }
                sleep(13000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SemaforoInferior.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
