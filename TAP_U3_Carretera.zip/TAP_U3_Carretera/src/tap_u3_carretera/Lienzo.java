package tap_u3_carretera;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

public class Lienzo extends Canvas {
    
    public int[] carroX1 = new int[4];
    public int[] carroY1 = new int[4];
    
    public int[] carroX2 = new int[5];
    public int[] carroY2 = new int[5];
    
    public int[] carroX3 = new int[4];
    public int[] carroY3 = new int[3];
    
    public int[] carrosX4 = new int[4];
    public int[] carrosY4 = new int[4];
    
    public Carro carro1;
    public Carro carro2;
    public Carro carro3;
    public Carro carro4;
    
    public Color Rojo1,Amarillo1,Verde1;
    public Color Rojo2,Amarillo2,Verde2;
    
    private Image dibujo;
    private Graphics gAux;
    private Dimension dimAux;
    private Dimension dimCanvas;
    
    SemaforoSuperior semaforoSuperior = new SemaforoSuperior();
    
    public Lienzo() {
        this.setVisible(true);
        this.setSize(1100, 850);
        
        dimCanvas = this.getSize();
        
        this.carroX1[0] = 50; this.carroX1[1] = 70; this.carroX1[2] = 110; this.carroX1[3] = 65;
        this.carroY1[0] = 270; this.carroY1[1] = 260; this.carroY1[2] = 350; this.carroY1[3] = 280;
        
        this.carroX2[0] = 950; this.carroX2[1] = 970; this.carroX2[2] = 1010; this.carroX2[3] = 975; this.carroX2[4] = 1015;
        this.carroY2[0] = 430; this.carroY2[1] = 970; this.carroY2[2] = 420; this.carroY2[3] = 510; this.carroY2[4] = 440;
        
        this.carroX3[0] = 425; this.carroX3[1] = 415; this.carroX3[2] = 505; this.carroX3[3] = 435;
        this.carroY3[0] = 650; this.carroY3[1] = 670; this.carroY3[2] = 710;
        
        this.carrosX4[0] = 580; this.carrosX4[1] = 570; this.carrosX4[2] = 660; this.carrosX4[3] = 590;
        this.carrosY4[0] = 25; this.carrosY4[1] = 45; this.carrosY4[2] = 85;
        
        carro1 = new Carro(this.carroX1,this.carroY1);
        carro2 = new Carro(this.carroX2,this.carroY2);
        carro3 = new Carro(this.carroX3,this.carroY3);
        carro4 = new Carro(this.carrosX4,this.carrosY4);
        
        Rojo1 = semaforoSuperior.colorR;
        Amarillo1 = semaforoSuperior.colorA;
        Verde1 = semaforoSuperior.colorV;
        
        Rojo2 = semaforoSuperior.colorR;
        Amarillo2 = semaforoSuperior.colorA;
        Verde2 = semaforoSuperior.colorV;
    }

    @Override
    public void update(Graphics g) {
        paint(g);
    }
    
    @Override
    public void paint(Graphics g) {
        if(gAux == null || dimAux == null || dimCanvas.width != dimAux.width || dimCanvas.height != dimAux.height){
            dimAux = dimCanvas;
            dibujo = createImage(dimAux.width,dimAux.height);
            gAux = dibujo.getGraphics();
        }
        super.paint(gAux);
        
        Graphics2D g2 = (Graphics2D) g;
        
        //Calles
        g2.setColor(Color.GRAY);
        g2.fillRect(0, 240, 1100, 300);
        g2.fillRect(390, 0, 300, 1100);
        
        //Semaforos rectangulo
        g2.setColor(Color.BLACK);
        g2.fillRect(275, 15, 100, 210);
        g2.fillRect(710, 560, 100, 210);
        
        //Lineas blancas izquierda
        g2.setColor(Color.WHITE);
        g2.fillRect(15, 385, 50, 10);
        g2.fillRect(115, 385, 50, 10);
        g2.fillRect(220, 385, 50, 10);
        g2.fillRect(325, 385, 50, 10);
        
        //Lineas blancas derecha
        g2.fillRect(1020, 385, 50, 10);
        g2.fillRect(915, 385, 50, 10);
        g2.fillRect(810, 385, 50, 10);
        g2.fillRect(710, 385, 50, 10);
        
        //Lineas blancas arriva
        g2.fillRect(540, 0, 10, 50);
        g2.fillRect(540, 90, 10, 50);
        g2.fillRect(540, 180, 10, 50);
        
        //Lineas blancas abajo
        g2.fillRect(540, 740, 10, 50);
        g2.fillRect(540, 650, 10, 50);
        g2.fillRect(540, 560, 10, 50);
        
        //Carro1
        g2.setColor(Color.blue);
        g2.fillRect(carro1.carroX[0], carro1.carroY[0], 100, 80);
        g2.setColor(Color.BLACK);
        g2.fillRect(carro1.carroX[1], carro1.carroY[1], 20, 10);
        g2.fillRect(carro1.carroX[1], carro1.carroY[2], 20, 10);
        g2.fillRect(carro1.carroX[2], carro1.carroY[1], 20, 10);
        g2.fillRect(carro1.carroX[2], carro1.carroY[2], 20, 10);
        g2.setColor(new Color(0,170,228));
        g2.fillRect(carro1.carroX[3], carro1.carroY[3], 20, 60);
        g2.fillRect(carro1.carroX[2], carro1.carroY[3], 20, 60);
        
        //Carro2
        g2.setColor(Color.blue);
        g2.fillRect(carro2.carroX[0], carro2.carroY[0], 100, 80);
        g2.setColor(Color.BLACK);
        g2.fillRect(carro2.carroX[1], carro2.carroY[2], 20, 10);
        g2.fillRect(carro2.carroX[1], carro2.carroY[3], 20, 10);
        g2.fillRect(carro2.carroX[2], carro2.carroY[2], 20, 10);
        g2.fillRect(carro2.carroX[2], carro2.carroY[3], 20, 10);
        g2.setColor(new Color(0,170,228));
        g2.fillRect(carro2.carroX[3], carro2.carroY[4], 20, 60);
        g2.fillRect(carro2.carroX[4], carro2.carroY[4], 20, 60);
        
        //Carro3
        g2.setColor(Color.blue);
        g2.fillRect(carro3.carroX[0], carro3.carroY[0], 80, 100);
        g2.setColor(Color.BLACK);
        g2.fillRect(carro3.carroX[1], carro3.carroY[1], 10, 20);
        g2.fillRect(carro3.carroX[1], carro3.carroY[2], 10, 20);
        g2.fillRect(carro3.carroX[2], carro3.carroY[1], 10, 20);
        g2.fillRect(carro3.carroX[2], carro3.carroY[2], 10, 20);
        g2.setColor(new Color(0,170,228));
        g2.fillRect(carro3.carroX[3], carro3.carroY[2], 60, 20);
        g2.fillRect(carro3.carroX[3], carro3.carroY[1], 60, 20);
        
        //Carro4
        g2.setColor(Color.blue);
        g2.fillRect(carro4.carroX[0], carro4.carroY[0], 80, 100);
        g2.setColor(Color.BLACK);
        g2.fillRect(carro4.carroX[1], carro4.carroY[1], 10, 20);
        g2.fillRect(carro4.carroX[1], carro4.carroY[2], 10, 20);
        g2.fillRect(carro4.carroX[2], carro4.carroY[1], 10, 20);
        g2.fillRect(carro4.carroX[2], carro4.carroY[2], 10, 20);
        g2.setColor(new Color(0,170,228));
        g2.fillRect(carro4.carroX[3], carro4.carroY[2], 60, 20);
        g2.fillRect(carro4.carroX[3], carro4.carroY[1], 60, 20);
        
        //Circulo superiores
        g2.setColor(Verde1);
        g2.fillOval(295, 158, 60, 60);
        g2.setColor(Amarillo1);
        g2.fillOval(295, 90, 60, 60);
        g2.setColor(Rojo1);
        g2.fillOval(295, 20, 60, 60);
        
        g2.setColor(Verde2);
        g2.fillOval(730, 700, 60, 60);
        g2.setColor(Amarillo2);
        g2.fillOval(730, 635, 60, 60);
        g2.setColor(Rojo2);
        g2.fillOval(730, 570, 60, 60);
    }

    public void setRojo1(Color Rojo1) {
        this.Rojo1 = Rojo1;
    }

    public void setAmarillo1(Color Amarillo1) {
        this.Amarillo1 = Amarillo1;
    }

    public void setVerde1(Color Verde1) {
        this.Verde1 = Verde1;
    }

    public void setRojo2(Color Rojo2) {
        this.Rojo2 = Rojo2;
    }

    public void setAmarillo2(Color Amarillo2) {
        this.Amarillo2 = Amarillo2;
    }

    public void setVerde2(Color Verde2) {
        this.Verde2 = Verde2;
    }
    
}
