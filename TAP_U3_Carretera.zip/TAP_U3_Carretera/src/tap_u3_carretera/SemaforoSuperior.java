package tap_u3_carretera;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SemaforoSuperior extends Thread{
    
    public final Color colorV = new Color(0,100,0);
    public final Color colorR = new Color(139,0,0);
    public final Color colorA = new Color(229,190,0);
    
    public final Color colorVL = new Color(0,255,0);
    public final Color colorRL = new Color(255,0,0);
    public final Color colorAL = new Color(255,255,0);
    
    public static boolean estadoSemaforoSuperior = false; //true = avanzar, false = detenerce.
    
    @Override
    public void run() {
        
        while(true){
            try {
                if(SemaforoInferior.estadoSemaforoInferior){
                    Ventana.lienzo.setRojo1(colorRL);
                    Ventana.lienzo.setAmarillo1(colorA);
                    Ventana.lienzo.setVerde1(colorV);
                    sleep(1000);
                    Ventana.lienzo.setRojo1(colorR);
                    Ventana.lienzo.setAmarillo1(colorAL);
                    Ventana.lienzo.setVerde1(colorV);
                    sleep(1000);
                    Ventana.lienzo.setRojo1(colorR);
                    Ventana.lienzo.setAmarillo1(colorA);
                    Ventana.lienzo.setVerde1(colorVL);
                    estadoSemaforoSuperior = true;
                    SemaforoInferior.estadoSemaforoInferior = false;
                }else{
                    Ventana.lienzo.setRojo1(colorR);
                    Ventana.lienzo.setAmarillo1(colorA);
                    Ventana.lienzo.setVerde1(colorVL);
                    sleep(1000);
                    Ventana.lienzo.setRojo1(colorR);
                    Ventana.lienzo.setAmarillo1(colorAL);
                    Ventana.lienzo.setVerde1(colorV);
                    sleep(1000);
                    Ventana.lienzo.setRojo1(colorRL);
                    Ventana.lienzo.setAmarillo1(colorA);
                    Ventana.lienzo.setVerde1(colorV);
                    estadoSemaforoSuperior = false;
                    SemaforoInferior.estadoSemaforoInferior = true;
                }
                sleep(13000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SemaforoSuperior.class.getName()).log(Level.SEVERE, null, ex);
            }    
        }
    }
    
}
